<?php require 'config.php'; ?>
 <!DOCTYPE html>
<html lang="en" dir="ltr">
	<head> 
		<meta charset="utf-8">
		<title>Import Excel To MySQL</title>
	</head>
	<body>
		<form class="" action="" method="post" enctype="multipart/form-data">
			<input type="file" name="excel" required value="">
			<button type="submit" name="import">Import</button>
		</form>
		<hr>
		
		<?php
		if(isset($_POST["import"])){
			$fileName = $_FILES["excel"]["name"];
			$fileExtension = explode('.', $fileName);
            $fileExtension = strtolower(end($fileExtension));
			$newFileName = date("Y.m.d") . " - " . date("h.i.sa") . "." . $fileExtension;

			$targetDirectory = "uploads/" . $newFileName;
			move_uploaded_file($_FILES['excel']['tmp_name'], $targetDirectory);

			error_reporting(0);
			ini_set('display_errors', 0);
			
			require 'excelReader/excel_reader2.php';
			require 'excelReader/SpreadsheetReader.php';

			$reader = new SpreadsheetReader($targetDirectory);
			foreach($reader as $key => $row){
				$fullname = $row[0];
				$user_name = $row[1];
				$user_pass = $row[2];
				$department = $row[3];
				$role = $row[4];
				$barcode = $row[5];
				$photo =  $row[6];
				$luser =  $row[7];
				mysqli_query($conn, "INSERT INTO `user_detail` (`id`, `fullname`, `user_name`, `user_pass`, `department`, `role`, `barcode`, `photo`, `luser`) VALUES (NULL, '$fullname', '$user_name', '$user_pass', '$department', '$role', '$barcode', '$photo', '$luser')");
			}

			echo
			"
			
			";
		}
		?>
	</body>
</html>
