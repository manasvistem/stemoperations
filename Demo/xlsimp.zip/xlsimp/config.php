<?php $conn = mysqli_connect("localhost", "steml1og_stemfun", "s0RkDLtTvN0t", "steml1og_stemf"); ?>
